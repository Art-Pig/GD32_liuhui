./objects/main.o: ../User/main.c \
  ../Firmware/CMSIS/GD/GD32E23x/Include\gd32e23x.h \
  C:/Keil_v5/ARM/PACK/ARM/CMSIS/5.0.1/CMSIS/Include\core_cm23.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  C:/Keil_v5/ARM/PACK/ARM/CMSIS/5.0.1/CMSIS/Include/cmsis_compiler.h \
  C:/Keil_v5/ARM/PACK/ARM/CMSIS/5.0.1/CMSIS/Include/cmsis_armclang.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\arm_compat.h \
  ../Firmware/CMSIS/GD/GD32E23x/Include/system_gd32e23x.h \
  ../User\gd32e23x_libopt.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_adc.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_crc.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_dbg.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_dma.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_exti.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_fmc.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_gpio.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_syscfg.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_i2c.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_fwdgt.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_pmu.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_rcu.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_rtc.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_spi.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_timer.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_usart.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_wwdgt.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_misc.h \
  ../Firmware/GD32E23x_standard_peripheral/Include\gd32e23x_cmp.h \
  ../User/systick.h C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdio.h \
  ../User/main.h ../Hardware\usart.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\string.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdlib.h
