#include "LED.h"


void LED_Init(){
	rcu_periph_clock_enable(RCU_GPIOB);
	
	gpio_init(GPIOB, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, LED1_PIN|LED2_PIN);
	gpio_bit_reset(GPIOB, LED1_PIN|LED2_PIN);
}

// ����LED1
void LED1_On(void){
	gpio_bit_set(GPIOB, LED1_PIN);
}

// Ϩ��LED1
void LED1_Off(void){
	gpio_bit_reset(GPIOB, LED1_PIN);
}

// ��תLED1 ������Ϩ���״̬
void LED1_Toggle(void){
	gpio_bit_write(GPIOB, LED1_PIN, (bit_status)!gpio_output_bit_get(GPIOB,LED1_PIN));
}

// ����LED2
void LED2_On(void){
	gpio_bit_set(GPIOB, LED2_PIN);
}

// Ϩ��LED2
void LED2_Off(void){
	gpio_bit_reset(GPIOB, LED2_PIN);
}

// ��תLED2 ������Ϩ���״̬
void LED2_Toggle(void){
	gpio_bit_write(GPIOB, LED2_PIN, (bit_status)!gpio_output_bit_get(GPIOB,LED2_PIN));
}
